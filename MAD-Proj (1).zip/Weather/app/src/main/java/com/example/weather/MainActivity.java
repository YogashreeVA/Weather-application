package com.example.weather;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class MainActivity extends AppCompatActivity {
    EditText et;
    TextView tv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        et = findViewById(R.id.et);
        tv = findViewById(R.id.wdata);
    }

    public void getWeather(View v) {
        String apikey = "6f976e9a8de2ae9c9d242e31697d5758";
        String city = et.getText().toString();

        String requestUrl = "https://api.openweathermap.org/data/2.5/weather?q=" + city + "&appid=" + apikey;
        RequestQueue queue = Volley.newRequestQueue(getApplicationContext());

        JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, requestUrl, null, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                try {
                    JSONObject main = response.getJSONObject("main");
                    double temperature = (double) main.get("temp") - 273.15;
                    double minTemp = (double) main.get("temp_min") - 273.15;
                    double maxTemp = (double) main.get("temp_max") - 273.15;
                    int pressure = (int) main.get("pressure");
                    int humidity = (int) main.get("humidity");

                    JSONArray weather = response.getJSONArray("weather");
                    String description = (String) weather.getJSONObject(0).get("description");

                    JSONObject clouds = response.getJSONObject("clouds");
                    int cloudiness = (int) clouds.get("all");

                    String data = "Temperature: " + Math.round(temperature) + " celcius\nMinimum Temperature: " + Math.round(minTemp) + " celcius\nMaximum Temperature: " + Math.round(maxTemp) + " celcius\nPressure: " + pressure + " bar\nHumidity: " + humidity + "%\nCloudiness: " + cloudiness + "%\nWeather Description: " + description;
                    tv.setText(data);
                } catch (JSONException e) {
                    Toast.makeText(getApplicationContext(), e.getMessage(), Toast.LENGTH_LONG).show();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(MainActivity.this, error.toString(), Toast.LENGTH_LONG).show();
            }
        });

        queue.add(request);
    }
}